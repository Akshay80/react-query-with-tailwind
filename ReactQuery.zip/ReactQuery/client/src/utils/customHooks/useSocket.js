// src/hooks/useSocket.js
import { useEffect, useState } from "react";
import io from "socket.io-client";

const SOCKET_SERVER_URL = "http://localhost:8000"; // Adjust if different

const useSocket = () => {
  const [socket, setSocket] = useState(null);

  useEffect(() => {
    const newSocket = io(SOCKET_SERVER_URL, {
      transports: ["websocket"],
    });
    setSocket(newSocket);

    // Clean up on unmount
    return () => newSocket.close();
  }, []);

  return socket;
};

export default useSocket;
