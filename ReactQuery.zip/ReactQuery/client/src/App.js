import React, { useEffect, useState } from "react";
import { Button, Modal } from "flowbite-react";
import { FaPlus } from "react-icons/fa6";
import { FaPencil } from "react-icons/fa6";
import { FaTrash } from "react-icons/fa6";
import { Toast } from "flowbite-react";
import { HiCheck, HiX } from "react-icons/hi";
import { useForm } from "react-hook-form";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import useSocket from "./utils/customHooks/useSocket";

const App = () => {
  const socket = useSocket();
  const {
    handleSubmit,
    register,
    setValue,
    reset,
    formState: { errors },
  } = useForm();

  const [RandomNumbers, setRandomNumbers] = useState(0);

  const queryClient = useQueryClient();


  useEffect(() => {
    if (!socket) return;

    // Listen for 'receiveRandomNumber' events from the server
    socket.on("receiveRandomNumber", (number) => {
      setRandomNumbers(number); // Prepend to show latest first
  
    });

    // Optional: Handle connection errors
    socket.on("connect_error", (err) => {
      console.error("Connection error:", err);
      showToast("error", "Connection error. Please try again.");
    });

    socket.on("disconnect", (reason) => {
      console.warn("Disconnected:", reason);
      showToast("error", "Disconnected from server.");
    });

    // Clean up the listener on component unmount
    return () => {
      socket.off("receiveRandomNumber");
      socket.off("connect_error");
      socket.off("disconnect");
    };
  }, [socket]);

  // MODAL STATES FOR SHOWING MODAL
  const [isAddModalOpen, setAddModalOpen] = useState(false);
  const [isEditModalOpen, setEditModalOpen] = useState(false);

  // MODAL STATES FOR SHOWING DELETE MODAL
  const [deleteModal, setDeleteModal] = useState(false);

  // SINGLE TOAST STATE FOR DYNAMIC TOASTS
  const [toast, setToast] = useState({
    show: false,
    type: "", // 'success' or 'error'
    message: "",
  });

  // HELPER FUNCTION TO SHOW TOAST
  const showToast = (type, message) => {
    setToast({
      show: true,
      type,
      message,
    });

    // Automatically hide the toast after 3 seconds
    setTimeout(() => {
      setToast((prev) => ({ ...prev, show: false }));
    }, 3000);
  };

  // FUNCTION FOR OPENING AND CLOSING OF ADD MODAL
  const openAddModal = () => {
    setAddModalOpen(true);
    reset();
  };

  const closeAddModal = () => {
    setAddModalOpen(false);
    reset();
  };

  // FUNCTION FOR OPENING AND CLOSING OF EDIT MODAL
  const openEditModal = () => setEditModalOpen(true);
  const closeEditModal = () => setEditModalOpen(false);

  // FUNCTION FOR ADDING NEW TODO STARTS
  const addTodo = async (newTodo) => {
    await fetch("http://localhost:8000/api/add-todo", {
      headers: {
        "Content-Type": "application/json",
      },
      method: "POST",
      body: JSON.stringify(newTodo),
    });
  };

  const addMutation = useMutation({
    mutationFn: addTodo,
    onSettled: () => queryClient.invalidateQueries({ queryKey: ["get-todos"] }),
    onSuccess: () => {
      showToast("success", "Todo added successfully.");
      closeAddModal();
    },
    onError: () => {
      showToast("error", "Failed to add todo.");
    },
  });

  // Handle form submission
  const handleAddTodo = (data) => {
    addMutation.mutate(data);
  };
  // FUNCTION FOR ADDING NEW TODO ENDS

  // FUNCTION FOR GETTING ALL TODO STARTS
  const getAllTodos = async () => {
    const response = await fetch("http://localhost:8000/api/all-todos");
    return response.json();
  };

  const { data } = useQuery({
    queryKey: ["get-todos"],
    queryFn: getAllTodos,
    refetchOnWindowFocus: false,
  });

  // FUNCTION FOR GETTING ALL TODO ENDS

  // FUNCTION FOR DELETING TODO STARTS

  const deleteTodo = async (todoId) => {
    await fetch(`http://localhost:8000/api/delete-todo/${todoId}`, {
      headers: {
        "Content-Type": "application/json",
      },
      method: "DELETE",
    });
  };

  const deleteMutation = useMutation({
    mutationFn: deleteTodo,
    onSettled: () => queryClient.invalidateQueries({ queryKey: ["get-todos"] }),
    onSuccess: () => {
      setDeleteModal(false);
      showToast("success", "Todo deleted successfully.");
    },
    onError: () => {
      showToast("error", "Failed to delete todo.");
    },
  });

  const openDelete = (id) => {
    window.localStorage.setItem("id", id);
    setDeleteModal(true);
  };

  const handleDelete = async () => {
    deleteMutation.mutate(window.localStorage.getItem("id"));
  };

  // FUNCTION FOR DELETING TODO ENDS

  // FUNCTION FOR EDITING TODO STARTS
  const editTodo = async (editedTodo) => {
    const id = window.localStorage.getItem("editId");
    await fetch(`http://localhost:8000/api/update-todo/${id}`, {
      headers: {
        "Content-Type": "application/json",
      },
      method: "PUT",
      body: JSON.stringify(editedTodo),
    });
  };

  const editMutation = useMutation({
    mutationFn: editTodo,
    onSettled: () => queryClient.invalidateQueries({ queryKey: ["get-todos"] }),
    onSuccess: () => {
      setEditModalOpen(false);
      showToast("success", "Todo updated successfully.");
    },
    onError: () => {
      showToast("error", "Failed to update todo.");
    },
  });

  const openEdit = async (id) => {
    window.localStorage.setItem("editId", id);

    await fetch(`http://localhost:8000/api/get-todo-by-id/${id}`, {
      headers: {
        "Content-Type": "application/json",
      },
      method: "GET",
    })
      .then((response) => response.json())
      .then((res) => {
        openEditModal();
        setValue("title", res.data.title);
        setValue("description", res.data.description);
      });
    // closeEditModal();
  };

  const handleEdit = async (data) => {
    editMutation.mutate(data);
  };
  // FUNCTION FOR EDITING TODO ENDS

  return (
    <div>
      <div className="bg-white shadow-md w-full max-w-lg rounded-lg overflow-hidden mx-auto font-sans mt-4">
        <div className="flex justify-between p-6">
          <h3 className="text-lg text-gray-500 leading-relaxed font-bold">
            Todo Lists
          </h3>
          <Button
            onClick={openAddModal}
            className="rounded-lg text-white bg-blue-600 hover:bg-blue-700 w-[40px] h-[40px] items-center focus:ring-0"
          >
            <FaPlus color="white" />
          </Button>
        </div>

        {/* TODO CARDS */}
        {data?.data.map((todo, index) => (
          <div
            key={index}
            className="bg-white shadow-md rounded-lg overflow-hidden mx-auto w-[90%] mb-4"
          >
            <div className="p-6 flex justify-between gap-3">
              <div>
                <h3 className="text-gray-800 text-xl font-bold">
                  {todo.title}
                </h3>
                <p className="mt-4 text-sm text-gray-500 leading-relaxed">
                  {todo.description}
                </p>
              </div>
              <div className="flex gap-3">
                <Button
                  onClick={() => openEdit(todo.id)}
                  className="rounded-lg text-white bg-green-400 hover:bg-green-500 focus:ring-0 h-[32px] w-[32px] items-center"
                >
                  <FaPencil color="white" />
                </Button>
                <Button
                  onClick={() => openDelete(todo.id)}
                  className="rounded-lg text-white bg-red-500 hover:bg-red-600 focus:ring-0 h-[32px] w-[32px] items-center"
                >
                  <FaTrash color="white" />
                </Button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* ADD MODAL */}
      <Modal
        show={isAddModalOpen}
        onClose={closeAddModal}
        size="md"
        centered="true"
        className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center"
      >
        <form className="space-y-4" onSubmit={handleSubmit(handleAddTodo)}>
          <Modal.Header className="text-gray-900 border-b-0 pb-1">
            Add Todo
          </Modal.Header>
          <Modal.Body>
            <div>
              <label
                htmlFor="todoTitle"
                className="block mb-2 text-sm font-medium text-gray-900"
              >
                Title
              </label>
              <input
                type="text"
                id="title"
                className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5"
                placeholder="Enter todo title"
                {...register("title", {
                  required: {
                    value: true,
                    message: "Title is required!",
                  },
                })}
              />
            </div>
            {errors.title && (
              <p className="text-red-500 text-[13px] pt-3">
                {errors.title.message}
              </p>
            )}
            <div className="mt-4">
              <label
                htmlFor="todoDescription"
                className="block mb-2 text-sm font-medium text-gray-900"
              >
                Description
              </label>
              <textarea
                id="description"
                rows="4"
                className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5"
                placeholder="Enter todo description"
                {...register("description", {
                  required: {
                    value: true,
                    message: "Description is required!",
                  },
                })}
              />
            </div>
            {errors.description && (
              <p className="text-red-500 text-[13px] pt-3">
                {errors.description.message}
              </p>
            )}
          </Modal.Body>
          <Modal.Footer className="border-t-0">
            <Button
              type="submit"
              // onClick={closeAddModal}
              className="bg-blue-600 hover:bg-blue-700 focus:ring-0"
            >
              Add Todo
            </Button>
          </Modal.Footer>
        </form>
      </Modal>

      {/* EDIT MODAL */}
      <Modal
        show={isEditModalOpen}
        onClose={closeEditModal}
        size="md"
        centered="true"
        className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center"
      >
        <form className="space-y-4" onSubmit={handleSubmit(handleEdit)}>
          <Modal.Header className="bg-white text-gray-900 border-b-0 pb-1">
            Edit Todo
          </Modal.Header>
          <Modal.Body className="space-y-6 ">
            <div>
              <label
                htmlFor="editTodoTitle"
                className="block mb-2 text-sm font-medium text-gray-900"
              >
                Title
              </label>
              <input
                type="text"
                id="editTodoTitle"
                className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5"
                placeholder="Edit todo title"
                {...register("title", {
                  required: {
                    value: true,
                    message: "Title is required!",
                  },
                })}
              />
            </div>
            <div>
              <label
                htmlFor="editTodoDescription"
                className="block mb-2 text-sm font-medium text-gray-900"
              >
                Description
              </label>
              <textarea
                id="editTodoDescription"
                rows="4"
                className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5"
                placeholder="Edit todo description"
                {...register("description", {
                  required: {
                    value: true,
                    message: "Description is required!",
                  },
                })}
              />
            </div>
          </Modal.Body>
          <Modal.Footer className="bg-white border-t-0">
            <Button
              type="submit"
              className="bg-green-600 hover:bg-green-700 items-end focus:ring-0"
            >
              Update Todo
            </Button>
          </Modal.Footer>
        </form>
      </Modal>

      {/* Dynamic Toast */}
      {toast.show && (
        <Toast className="absolute top-6 right-6 z-50">
          <div
            className={`inline-flex h-8 w-8 shrink-0 items-center justify-center rounded-lg ${
              toast.type === "success"
                ? "bg-green-100 text-green-500"
                : "bg-red-100 text-red-500"
            }`}
          >
            {toast.type === "success" ? (
              <HiCheck className="h-5 w-5" />
            ) : (
              <HiX className="h-5 w-5" />
            )}
          </div>
          <div className="ml-3 text-sm font-normal">{toast.message}</div>
          <Toast.Toggle onClick={() => setToast({ ...toast, show: false })} />
        </Toast>
      )}

      {/* DELETE MODAL */}
      <Modal
        show={deleteModal}
        size="md"
        onClose={() => setDeleteModal(false)}
        popup
      >
        <Modal.Header className="pt-4 ms-3">
          <h4>Delete Todo</h4>
        </Modal.Header>
        <Modal.Body>
          <div className="mt-2">
            <h3 className="mb-5 text-lg font-normal text-gray-500 dark:text-gray-400">
              Are you sure you want to delete this todo?
            </h3>
            <div className="flex justify-end gap-4 mt-8">
              <Button
                color="success"
                className="ring-0 focus:ring-0"
                onClick={() => handleDelete()}
              >
                {"Yes, I'm sure"}
              </Button>
              <Button
                color="failure"
                className="ring-0 focus:ring-0"
                onClick={() => setDeleteModal(false)}
              >
                No, cancel
              </Button>
            </div>
          </div>
        </Modal.Body>
      </Modal>

      <div>{RandomNumbers}</div>

      {/* DELETE MODAL ENDS HERE*/}
    </div>
  );
};

export default App;
