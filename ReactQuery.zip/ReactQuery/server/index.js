const dotenv = require("dotenv");
dotenv.config();

const express = require("express");
const app = express();
const cors = require("cors");
const bodyParser = require("body-parser");
const TodoRoute = require("./Routes/todoRoutes");
const http = require("http");
const socketIo = require("socket.io");
const mongoose = require("mongoose");

const PORT = process.env.PORT || 8000;

// Middleware Setup
app.use(cors());
app.use(express.urlencoded({ extended: true }));
app.use(bodyParser.json());

// Routes
app.use("/api", TodoRoute);

// Database Connection
mongoose
  .connect(process.env.MONGO_URI, {
    useNewUrlParser: true,
    useUnifiedTopology: true,
  })
  .then(() => console.log("MongoDB connected"))
  .catch((err) => console.error("MongoDB connection error:", err));

// Create HTTP server
const server = http.createServer(app);

// Initialize Socket.IO
const io = socketIo(server, {
  cors: {
    origin: "http://localhost:3000", // React app's origin
    methods: ["GET", "POST"],
  },
});

// Listen for client connections
io.on("connection", (socket) => {
  // Emit random numbers to the client every second
  const interval = setInterval(() => {
    const randomNumber = Math.floor(Math.random() * 100000) + 1; // 1 to 100000
    socket.emit("receiveRandomNumber", randomNumber);
  }, 1000); // 1 second interval

  // Handle client disconnection
  socket.on("disconnect", () => {
    clearInterval(interval);
  });
});

// Start the server
server.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
