const mongoose = require("mongoose");
const { v4: uuidv4 } = require("uuid");

const TodoSchema = new mongoose.Schema(
  {
    id: {
      type: String,
      default: uuidv4,
      unique: true,
    },
    title: {
      type: String,
    },
    description: {
      type: String,
    },
  },
  { timestamps: true ,
    toJSON: {
      transform: function(doc, ret) {
        delete ret._id;   // Remove _id from response
        delete ret.__v;   // Optionally remove __v as well
        return ret;
      }
    }
  },
  
);

module.exports = mongoose.model("Todo", TodoSchema);
