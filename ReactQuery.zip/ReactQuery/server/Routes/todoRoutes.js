const express = require("express");
const TodoModel = require("../Schema/todoSchema");

const router = express.Router();

// GET all Todos
router.get("/all-todos", async (req, res) => {
  try {
    const todos = await TodoModel.find();
    res.status(200).json({ sucess: true, data: todos });
  } catch (error) {
    res.status(500).json({ sucess: false, data: [], message: error.message });
  }
});

// GET all Todos
router.get("/get-todo-by-id/:id", async (req, res) => {
  const { id } = req.params;

  try {
    const todos = await TodoModel.findOne({ id: id });
    res.status(200).json({ sucess: true, data: todos });
  } catch (error) {
    res.status(500).json({ sucess: false, data: [], message: error.message });
  }
});

// POST a new Todo
router.post("/add-todo", async (req, res) => {
  const { title, description } = req.body;
  const newTodo = new TodoModel({
    title: title,
    description: description,
  });

  try {
    const savedTodo = await newTodo.save();
    res.status(201).json({
      sucess: true,
      message: "Todo saved successully",
      data: savedTodo,
    });
  } catch (error) {
    res.status(500).json({ success: false, data: [], message: error.message });
  }
});

// PUT (update) a Todo by UUID
router.put("/update-todo/:id", async (req, res) => {
  const { id } = req.params;
  const { title, description } = req.body;

  try {
    const updatedTodo = await TodoModel.findOneAndUpdate(
      { id }, // Query by UUID
      { title, description },
      { new: true }
    );
    if (updatedTodo) {
      res.status(200).json({
        sucess: true,
        message: "Todo updated successfully",
        data: updatedTodo,
      });
    } else {
      res.status(404).json({ message: "Todo not found" });
    }
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// DELETE a Todo by UUID
router.delete("/delete-todo/:id", async (req, res) => {
  const { id } = req.params;

  try {
    const deletedTodo = await TodoModel.findOneAndDelete({ id });
    if (deletedTodo) {
      res
        .status(200)
        .json({ success: true, message: "Todo deleted successully" });
    } else {
      res.status(404).json({ success: false, message: "Todo not found" });
    }
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

module.exports = router;
